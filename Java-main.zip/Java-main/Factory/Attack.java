import java.util.ArrayList;

public interface Attack {

  public ArrayList<String> passWordCracker();
  
}
