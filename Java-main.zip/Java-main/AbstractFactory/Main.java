public class Main 
{
    public static void main(String[] args) 
  {
    DisplayTheContinentInformation displayTheContinentInformation = new DisplayTheContinentInformation();
    displayTheContinentInformation.display();
  }
}
