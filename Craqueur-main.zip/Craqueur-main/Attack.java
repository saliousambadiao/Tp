import java.io.IOException;

public interface Attack {
    
    public String passwordCracker() throws IOException, Exception;
}
