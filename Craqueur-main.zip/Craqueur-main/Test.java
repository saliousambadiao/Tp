import java.util.Scanner;
public class Test {
    public static void main(String args[]) throws Exception {
        try (Scanner sc = new Scanner(System.in)) {
          System.out.println("choose \n 1 for 'Brute Force Attack' \n 2 for 'Dictionary Attack'");
          int choice=sc.nextInt();
          if(choice==1) {
          
            Attack attack1 = new ForceBrute();
            ((ForceBrute) attack1).passwordCracker();
          }
          else if(choice==2) {
            Attack attack2 = new Dictionnaire();
            ((Dictionnaire) attack2).passwordCracker();
          }
        }
    }
}